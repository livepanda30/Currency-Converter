package com.example.currencncyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Spinner sp1,sp2;
    EditText ed1;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1 =findViewById(R.id.txtamount);
        sp1 =findViewById(R.id.spfrom);
        sp2 =findViewById(R.id.spto);
        b1 =findViewById(R.id.btn1);



        String[] from = {"USD","EU","JPY","CAD","HKD",};
        ArrayAdapter ad =new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,from );
        sp1.setAdapter(ad);

        String[] to = {"EU","JPY","CAD","HKD","USD"};
        ArrayAdapter ad1 =new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,to );
        sp2.setAdapter(ad1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double tot;
                double amount = Double.parseDouble(ed1.getText().toString());
                if (sp1.getSelectedItem() != null && sp1.getSelectedItem().toString() == "USD" && sp2.getSelectedItem().toString() == "INR") {
                    tot = amount * 70.0;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                } else if (sp1.getSelectedItem().toString() == "USD" && sp2.getSelectedItem().toString() == "EU") {
                    tot = amount * 0.859542;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "USD" && sp2.getSelectedItem().toString() == "JPY") {
                    tot = amount * 107.88;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "USD" && sp2.getSelectedItem().toString() == "CAD") {
                    tot = amount * 1.25;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "USD" && sp2.getSelectedItem().toString() == "HKD") {
                    tot = amount * 7.76;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "USD" && sp2.getSelectedItem().toString() == "USD") {
                    tot = amount * 1.0;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "EU" && sp2.getSelectedItem().toString() == "EU") {
                    tot = amount * 1.0;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "EU" && sp2.getSelectedItem().toString() == "USD") {
                    tot = amount * 1.21;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "EU" && sp2.getSelectedItem().toString() == "CAD") {
                    tot = amount * 1.51;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "EU" && sp2.getSelectedItem().toString() == "JPY") {
                    tot = amount * 130.56;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "EU" && sp2.getSelectedItem().toString() == "HKD") {
                    tot = amount * 9.39;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "CAD" && sp2.getSelectedItem().toString() == "CAD") {
                    tot = amount * 1.0;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "CAD" && sp2.getSelectedItem().toString() == "USD") {
                    tot = amount * .80;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "CAD" && sp2.getSelectedItem().toString() == "EU") {
                    tot = amount * .66;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "CAD" && sp2.getSelectedItem().toString() == "HKD") {
                    tot = amount * 6.22;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "CAD" && sp2.getSelectedItem().toString() == "JPY") {
                    tot = amount * 86.51;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "HKD" && sp2.getSelectedItem().toString() == "HKD") {
                    tot = amount * 1.0;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "HKD" && sp2.getSelectedItem().toString() == "CAD") {
                    tot = amount * 0.16;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "HKD" && sp2.getSelectedItem().toString() == "EU") {
                    tot = amount * 0.11;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "HKD" && sp2.getSelectedItem().toString() == "USD") {
                    tot = amount * 0.13;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "HKD" && sp2.getSelectedItem().toString() == "JPY") {
                    tot = amount * 13.90;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "JPY" && sp2.getSelectedItem().toString() == "JPY") {
                    tot = amount * 1.0;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "JPY" && sp2.getSelectedItem().toString() == "HKD") {
                    tot = amount * .072;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "JPY" && sp2.getSelectedItem().toString() == "EU") {
                    tot = amount * 0077;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "JPY" && sp2.getSelectedItem().toString() == "USD") {
                    tot = amount * .0093;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }else if (sp1.getSelectedItem().toString() == "JPY" && sp2.getSelectedItem().toString() == "CAD") {
                    tot = amount * .012;
                    Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                }




            }
        });


    }
}